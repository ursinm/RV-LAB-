package by.bsuir.dc.lab4.kafka;

public interface DtoBase {
    Long id = 0L;

    public Long getId();
}
