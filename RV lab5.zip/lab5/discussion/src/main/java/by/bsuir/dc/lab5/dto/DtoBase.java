package by.bsuir.dc.lab5.dto;

public interface DtoBase {
    Long id = 0L;

    Long getId();
}
