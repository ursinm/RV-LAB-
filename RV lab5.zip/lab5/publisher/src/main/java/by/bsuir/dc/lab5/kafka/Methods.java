package by.bsuir.dc.lab5.kafka;

public enum Methods {
    GET_BY_ID,
    GET_ALL,
    DELETE,
    UPDATE,
    CREATE
}
